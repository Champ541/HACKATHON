
# app.py - Flask Backend for Potato Defect Detection System

from flask import Flask, request, jsonify, g
from flask_cors import CORS
import psycopg2
from psycopg2.extras import RealDictCursor
import cv2
import numpy as np
import tensorflow as tf
from datetime import datetime
import os
import logging
from typing import Dict, List, Optional
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Database configuration
DB_CONFIG = {
    'host': 'localhost',
    'database': 'potato_defects',
    'user': 'postgres',
    'password': 'password',
    'port': 5432
}

# AI Model configuration
MODEL_PATH = 'models/potato_defect_model_v2.3.h5'
DEFECT_CLASSES = ['Healthy', 'Hollow Heart', 'Black Heart', 'Internal Heat Necrosis']

class PotatoDefectDetector:
    def __init__(self, model_path: str):
        self.model_path = model_path
        self.model = None
        self.load_model()

    def load_model(self):
        """Load the trained TensorFlow model"""
        try:
            self.model = tf.keras.models.load_model(self.model_path)
            logger.info(f"Model loaded successfully from {self.model_path}")
        except Exception as e:
            logger.error(f"Error loading model: {e}")
            raise

    def preprocess_image(self, image_path: str) -> np.ndarray:
        """Preprocess image for model prediction"""
        try:
            # Load and preprocess image
            image = cv2.imread(image_path)
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            image = cv2.resize(image, (224, 224))  # Resize to model input size
            image = image.astype(np.float32) / 255.0  # Normalize
            image = np.expand_dims(image, axis=0)  # Add batch dimension
            return image
        except Exception as e:
            logger.error(f"Error preprocessing image: {e}")
            raise

    def predict_defect(self, image_path: str) -> Dict:
        """Predict defect type and confidence from image"""
        try:
            start_time = datetime.now()

            # Preprocess image
            processed_image = self.preprocess_image(image_path)

            # Make prediction
            predictions = self.model.predict(processed_image)

            # Get predicted class and confidence
            predicted_class_idx = np.argmax(predictions[0])
            confidence = float(predictions[0][predicted_class_idx])
            defect_type = DEFECT_CLASSES[predicted_class_idx]

            processing_time = (datetime.now() - start_time).total_seconds() * 1000

            return {
                'defect_type': defect_type,
                'confidence': confidence,
                'processing_time_ms': int(processing_time),
                'all_predictions': {
                    DEFECT_CLASSES[i]: float(predictions[0][i]) 
                    for i in range(len(DEFECT_CLASSES))
                }
            }
        except Exception as e:
            logger.error(f"Error predicting defect: {e}")
            raise

# Initialize detector
detector = PotatoDefectDetector(MODEL_PATH)

def get_db_connection():
    """Get database connection"""
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        return conn
    except Exception as e:
        logger.error(f"Database connection error: {e}")
        raise

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'model_loaded': detector.model is not None
    })

@app.route('/api/scan', methods=['POST'])
def scan_potato():
    """Scan a single potato for defects"""
    try:
        data = request.get_json()

        # Validate required fields
        required_fields = ['batch_number', 'potato_id', 'image_path', 'inspector_name']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400

        # Predict defect
        prediction_result = detector.predict_defect(data['image_path'])

        # Store result in database
        conn = get_db_connection()
        cur = conn.cursor()

        cur.execute("""
            INSERT INTO potato_scans 
            (batch_number, potato_id, image_path, defect_type, confidence_score, 
             inspector_name, model_version, processing_time_ms)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING scan_id;
        """, (
            data['batch_number'],
            data['potato_id'],
            data['image_path'],
            prediction_result['defect_type'],
            prediction_result['confidence'],
            data['inspector_name'],
            'v2.3',
            prediction_result['processing_time_ms']
        ))

        scan_id = cur.fetchone()[0]
        conn.commit()
        cur.close()
        conn.close()

        return jsonify({
            'scan_id': scan_id,
            'defect_type': prediction_result['defect_type'],
            'confidence': prediction_result['confidence'],
            'processing_time_ms': prediction_result['processing_time_ms'],
            'status': 'success'
        })

    except Exception as e:
        logger.error(f"Error in scan_potato: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/scans', methods=['GET'])
def get_scans():
    """Get scan results with optional filtering"""
    try:
        # Get query parameters
        batch_number = request.args.get('batch_number')
        defect_type = request.args.get('defect_type')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        limit = int(request.args.get('limit', 100))
        offset = int(request.args.get('offset', 0))

        # Build query
        query = "SELECT * FROM potato_scans WHERE 1=1"
        params = []

        if batch_number:
            query += " AND batch_number = %s"
            params.append(batch_number)

        if defect_type:
            query += " AND defect_type = %s"
            params.append(defect_type)

        if start_date:
            query += " AND scan_timestamp >= %s"
            params.append(start_date)

        if end_date:
            query += " AND scan_timestamp <= %s"
            params.append(end_date)

        query += " ORDER BY scan_timestamp DESC LIMIT %s OFFSET %s"
        params.extend([limit, offset])

        conn = get_db_connection()
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute(query, params)
        scans = cur.fetchall()
        cur.close()
        conn.close()

        return jsonify([dict(scan) for scan in scans])

    except Exception as e:
        logger.error(f"Error in get_scans: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/statistics', methods=['GET'])
def get_statistics():
    """Get system statistics"""
    try:
        conn = get_db_connection()
        cur = conn.cursor()

        # Total scans
        cur.execute("SELECT COUNT(*) FROM potato_scans")
        total_scanned = cur.fetchone()[0]

        # Defects found
        cur.execute("SELECT COUNT(*) FROM potato_scans WHERE defect_type != 'Healthy'")
        defects_found = cur.fetchone()[0]

        # Average confidence
        cur.execute("SELECT AVG(confidence_score) FROM potato_scans")
        avg_confidence = cur.fetchone()[0]

        # Defect distribution
        cur.execute("""
            SELECT defect_type, COUNT(*) as count, 
                   ROUND((COUNT(*) * 100.0 / %s), 1) as percentage
            FROM potato_scans 
            GROUP BY defect_type
        """, (total_scanned,))
        defect_distribution = cur.fetchall()

        cur.close()
        conn.close()

        return jsonify({
            'total_scanned': total_scanned,
            'defects_found': defects_found,
            'accuracy_rate': round(avg_confidence * 100, 1) if avg_confidence else 0,
            'throughput_per_hour': 3600,  # Configurable
            'system_uptime': '99.7%',  # From system monitoring
            'defect_distribution': [
                {
                    'type': row[0],
                    'count': row[1],
                    'percentage': row[2]
                } for row in defect_distribution
            ]
        })

    except Exception as e:
        logger.error(f"Error in get_statistics: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/batch', methods=['POST'])
def create_batch():
    """Create a new potato batch"""
    try:
        data = request.get_json()

        conn = get_db_connection()
        cur = conn.cursor()

        cur.execute("""
            INSERT INTO potato_batches 
            (batch_number, supplier_name, harvest_date, storage_conditions, total_potatoes)
            VALUES (%s, %s, %s, %s, %s)
            RETURNING batch_id;
        """, (
            data['batch_number'],
            data.get('supplier_name'),
            data.get('harvest_date'),
            data.get('storage_conditions'),
            data.get('total_potatoes', 0)
        ))

        batch_id = cur.fetchone()[0]
        conn.commit()
        cur.close()
        conn.close()

        return jsonify({'batch_id': batch_id, 'status': 'success'})

    except Exception as e:
        logger.error(f"Error in create_batch: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
