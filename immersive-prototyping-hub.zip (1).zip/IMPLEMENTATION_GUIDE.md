
# Implementation Guide: Non-Invasive AI Potato Defect Detection System

## Table of Contents
1. [System Overview](#system-overview)
2. [Hardware Requirements](#hardware-requirements)
3. [Software Setup](#software-setup)
4. [Installation Steps](#installation-steps)
5. [Configuration](#configuration)
6. [Testing & Calibration](#testing--calibration)
7. [Production Deployment](#production-deployment)
8. [Maintenance & Monitoring](#maintenance--monitoring)

## System Overview

This comprehensive guide covers the implementation of a non-invasive AI-powered potato defect detection system capable of identifying internal defects (hollow heart, black heart, internal heat necrosis) without cutting or damaging the potatoes.

### Key Features:
- **Non-destructive detection** using hyperspectral imaging and AI
- **Real-time processing** at production line speeds (up to 3,600 potatoes/hour)
- **High accuracy** (94-97% detection rate)
- **Automated sorting** into quality bins
- **Web-based dashboard** for monitoring and analytics
- **Database integration** for traceability and quality control

## Hardware Requirements

### Imaging Hardware
```
Primary Sensors:
- Hyperspectral camera (900-1700nm NIR/SWIR range)
  - Recommended: Specim FX series or equivalent
  - Resolution: minimum 640×480 pixels
  - Frame rate: 60+ fps

- High-resolution RGB cameras (2-4 units for 360° coverage)
  - Recommended: Basler ace series or equivalent
  - Resolution: minimum 2048×1536 pixels
  - Frame rate: 30+ fps

Optional Sensors:
- X-ray imaging system (for additional internal analysis)
- Thermal imaging camera (for heat-related defects)
```

### Illumination System
```
- LED lighting arrays with controlled spectrum
- Diffuse lighting setup to minimize shadows
- Adjustable intensity (0-100%)
- Color temperature: 5000K-6500K
```

### Computing Hardware
```
Processing Unit:
- Industrial PC or embedded system
- CPU: Intel i7/i9 or AMD Ryzen 7/9 (minimum 8 cores)
- RAM: 32GB DDR4 minimum (64GB recommended)
- GPU: NVIDIA RTX 3070/4070 or better (for AI inference)
- Storage: 2TB NVMe SSD (for image storage and processing)

Edge Computing Option:
- NVIDIA Jetson AGX Xavier/Orin
- Raspberry Pi 4 with AI accelerator (for smaller operations)
```

### Mechanical Components
```
Conveyor System:
- Variable speed belt conveyor (0.5-2.0 m/s)
- Food-grade materials (stainless steel, FDA-approved plastics)
- Encoder feedback for position tracking

Sorting Mechanism:
- Pneumatic ejectors or robotic arms
- Response time: <50ms
- Sorting bins: 4-6 categories
- Capacity: 50+ potatoes/minute per lane
```

## Software Setup

### Operating System
```bash
# Recommended: Ubuntu 20.04 LTS or CentOS 8
sudo apt update && sudo apt upgrade -y

# Install system dependencies
sudo apt install -y build-essential cmake git wget curl
sudo apt install -y python3 python3-pip python3-venv
sudo apt install -y postgresql postgresql-contrib nginx
```

### Python Environment
```bash
# Create virtual environment
python3 -m venv potato_detection_env
source potato_detection_env/bin/activate

# Install core packages
pip install --upgrade pip setuptools wheel

# AI/ML packages
pip install tensorflow==2.13.0
pip install opencv-python==4.8.0.74
pip install scikit-learn==1.3.0
pip install numpy==1.24.3
pip install scipy==1.10.1

# Image processing
pip install pillow==10.0.0
pip install scikit-image==0.20.0
pip install matplotlib==3.7.1

# Web framework
pip install flask==2.3.2
pip install flask-cors==4.0.0
pip install psycopg2-binary==2.9.6

# Database ORM
pip install sqlalchemy==2.0.18

# Hardware communication
pip install pyserial==3.5
```

## Installation Steps

### Step 1: Database Setup
```bash
# Start PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database and user
sudo -u postgres psql << EOF
CREATE DATABASE potato_defects;
CREATE USER potato_user WITH PASSWORD 'secure_password123';
GRANT ALL PRIVILEGES ON DATABASE potato_defects TO potato_user;
\q
EOF

# Initialize database schema
psql -U potato_user -d potato_defects -f database_schema.sql
```

### Step 2: Project Structure Setup
```bash
mkdir -p /opt/potato_detection
cd /opt/potato_detection

# Create directory structure
mkdir -p {models,data/{images,spectral},logs,config,static,templates}
mkdir -p web/{static/{css,js,images},templates}

# Copy application files
cp flask_backend.py /opt/potato_detection/
cp potato_defect_model.py /opt/potato_detection/
cp image_processing.py /opt/potato_detection/
cp hardware_integration.py /opt/potato_detection/
```

### Step 3: Configuration Files
Create configuration file `/opt/potato_detection/config/system_config.yaml`:
```yaml
# System Configuration
database:
  host: localhost
  port: 5432
  database: potato_defects
  user: potato_user
  password: secure_password123

ai_model:
  model_path: models/potato_defect_model_v2.3.h5
  confidence_threshold: 0.85
  batch_size: 32
  input_size: [224, 224, 3]

hardware:
  conveyor:
    port: /dev/ttyUSB0
    baud_rate: 9600
    default_speed: 50

  sorter:
    port: /dev/ttyUSB1
    baud_rate: 9600
    response_delay_ms: 100

  cameras:
    primary:
      device_id: 0
      resolution: [1920, 1080]
      fps: 30

    hyperspectral:
      device_id: 1
      spectral_range: [900, 1700]
      integration_time: 10

imaging:
  save_images: true
  image_format: jpg
  compression_quality: 95
  storage_path: data/images

processing:
  max_concurrent: 4
  timeout_seconds: 30
  enable_gpu: true

web_interface:
  host: 0.0.0.0
  port: 5000
  debug: false
  secret_key: your_secret_key_here
```

### Step 4: Web Interface Setup
```bash
# Install Node.js for frontend dependencies (if needed)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Setup Nginx reverse proxy
sudo tee /etc/nginx/sites-available/potato_detection << EOF
server {
    listen 80;
    server_name your_server_ip_or_domain;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    }

    location /static {
        alias /opt/potato_detection/web/static;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
EOF

sudo ln -s /etc/nginx/sites-available/potato_detection /etc/nginx/sites-enabled/
sudo systemctl restart nginx
```

## Configuration

### Step 5: AI Model Training (if needed)
```python
# Train custom model with your potato dataset
from potato_defect_model import PotatoDefectCNN

# Initialize model
model = PotatoDefectCNN(input_shape=(224, 224, 3), num_classes=4)

# Train on your dataset
history = model.train_model(
    data_dir='path/to/your/potato/dataset',
    epochs=50,
    batch_size=32,
    validation_split=0.2
)

# Save trained model
model.save_model('models/potato_defect_model_v2.3.h5')
```

### Step 6: Hardware Calibration
```python
# Calibrate hardware components
from hardware_integration import SystemController

system = SystemController()

# Initialize and test all components
if system.initialize_system():
    print("Hardware initialization successful")

    # Calibrate conveyor speed
    system.conveyor.set_speed(50)  # Adjust based on throughput needs

    # Test sorting mechanism
    for bin_type in ['healthy', 'hollow_heart', 'black_heart', 'internal_heat_necrosis']:
        system.sorter.sort_potato(bin_type)
        time.sleep(1)
else:
    print("Hardware initialization failed - check connections")
```

## Testing & Calibration

### Performance Testing
```bash
# Run system performance tests
cd /opt/potato_detection
python -m pytest tests/ -v

# Test AI model accuracy
python test_model_accuracy.py --test_data data/test_images/

# Test hardware integration
python test_hardware.py --full_system_test
```

### Calibration Procedure
1. **Image Quality Calibration**
   - Adjust lighting intensity and angles
   - Verify focus and exposure settings
   - Test with known good/defective samples

2. **AI Model Validation**
   - Run validation dataset through system
   - Verify accuracy meets requirements (>94%)
   - Adjust confidence thresholds if needed

3. **Mechanical Timing**
   - Synchronize camera triggers with conveyor position
   - Calibrate sorting mechanism timing
   - Test end-to-end processing pipeline

## Production Deployment

### Step 7: Production Setup
```bash
# Create systemd service for automatic startup
sudo tee /etc/systemd/system/potato-detection.service << EOF
[Unit]
Description=Potato Defect Detection System
After=network.target postgresql.service

[Service]
Type=simple
User=potato
WorkingDirectory=/opt/potato_detection
Environment=PATH=/opt/potato_detection/potato_detection_env/bin
ExecStart=/opt/potato_detection/potato_detection_env/bin/python flask_backend.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Enable and start service
sudo systemctl enable potato-detection.service
sudo systemctl start potato-detection.service
```

### Step 8: Monitoring & Logging
```bash
# Setup log rotation
sudo tee /etc/logrotate.d/potato-detection << EOF
/opt/potato_detection/logs/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    copytruncate
}
EOF

# Monitor system status
sudo systemctl status potato-detection.service
sudo journalctl -u potato-detection.service -f
```

## Maintenance & Monitoring

### Daily Checks
- [ ] Verify system is running and processing potatoes
- [ ] Check processing accuracy and throughput metrics
- [ ] Review error logs for any issues
- [ ] Confirm all sorting bins are functioning correctly

### Weekly Maintenance
- [ ] Clean camera lenses and sensors
- [ ] Calibrate lighting system
- [ ] Review and analyze quality control data
- [ ] Update AI model if new training data is available

### Monthly Tasks
- [ ] Full system backup
- [ ] Hardware inspection and cleaning
- [ ] Performance optimization review
- [ ] Security updates and patches

### Troubleshooting Guide

#### Common Issues
1. **Low Detection Accuracy**
   - Check camera focus and cleanliness
   - Verify lighting conditions
   - Retrain AI model with more data

2. **Slow Processing Speed**
   - Monitor CPU/GPU utilization
   - Check network connectivity
   - Optimize image processing parameters

3. **Hardware Communication Errors**
   - Verify serial connections
   - Check cable integrity
   - Restart hardware controllers

#### Performance Monitoring
```bash
# Monitor system resources
htop
nvidia-smi  # For GPU monitoring

# Check database performance
sudo -u postgres psql -d potato_defects -c "
SELECT schemaname,tablename,attname,avg_width,n_distinct,correlation 
FROM pg_stats WHERE schemaname='public';
"

# View application logs
tail -f /opt/potato_detection/logs/application.log
```

## Support & Documentation

### Additional Resources
- API Documentation: http://your_system_ip/api/docs
- User Manual: Available in web interface
- Technical Support: Contact system administrator

### Backup & Recovery
```bash
# Database backup
pg_dump -U potato_user potato_defects > backup_$(date +%Y%m%d).sql

# Full system backup
tar -czf system_backup_$(date +%Y%m%d).tar.gz /opt/potato_detection/

# Model backup
cp models/potato_defect_model_v2.3.h5 models/backup/
```

This implementation guide provides a complete roadmap for deploying a production-ready potato defect detection system. Follow each step carefully and adapt configurations to your specific hardware and requirements.
