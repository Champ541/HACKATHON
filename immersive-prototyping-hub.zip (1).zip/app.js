// Application data from the provided JSON
const appData = {
    projects: [
        {"id": "PRJ001", "name": "Automotive Engine Block", "status": "Active", "team_members": 8, "cost_savings": "$45,000", "time_saved": "6 weeks", "completion": 75},
        {"id": "PRJ002", "name": "Industrial Pump Assembly", "status": "Review", "team_members": 5, "cost_savings": "$28,000", "time_saved": "4 weeks", "completion": 90},
        {"id": "PRJ003", "name": "Aerospace Component", "status": "Testing", "team_members": 12, "cost_savings": "$82,000", "time_saved": "8 weeks", "completion": 60}
    ],
    platform_stats: {
        total_projects: 156,
        active_users: 342,
        total_cost_savings: "$2.4M",
        time_reduction: "65%",
        safety_incidents_reduced: "78%"
    },
    collaboration_sessions: [
        {"project": "Engine Block", "participants": ["John Smith", "Sarah Chen", "Mike Johnson"], "status": "Live", "duration": "1h 23m"},
        {"project": "Pump Assembly", "participants": ["Lisa Wang", "David Brown"], "status": "Scheduled", "start_time": "2:00 PM"}
    ],
    performance_metrics: [
        {"metric": "Physical Prototyping Cost", "traditional": "$3,500", "immersive": "$750", "savings": "79%"},
        {"metric": "Development Time", "traditional": "21 days", "immersive": "3 days", "savings": "86%"},
        {"metric": "Training Cost", "traditional": "$986", "immersive": "$300", "savings": "70%"},
        {"metric": "Safety Incidents", "traditional": "2.8/100", "immersive": "0.5/100", "reduction": "82%"}
    ],
    recent_activities: [
        {"user": "John Smith", "action": "Updated CAD model", "project": "Engine Block", "time": "5 minutes ago"},
        {"user": "Sarah Chen", "action": "Completed simulation", "project": "Pump Assembly", "time": "12 minutes ago"},
        {"user": "Mike Johnson", "action": "Added design review comments", "project": "Aerospace Component", "time": "1 hour ago"}
    ]
};

// Global variables
let currentView = 'dashboard';
let filteredProjects = [...appData.projects];
let costSavingsChart;
let productivityChart;

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    setupNavigation();
    setupTime();
    populateDashboard();
    populateProjects();
    setupProjectManagement();
    setupCollaborationHub();
    setupResourceLibrary();
    setupModal();
    setTimeout(() => {
        setupCharts();
    }, 100);
}

// Navigation System
function setupNavigation() {
    const navItems = document.querySelectorAll('.nav__item');
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const targetView = this.dataset.view;
            switchView(targetView);
            
            // Update active state
            navItems.forEach(nav => nav.classList.remove('nav__item--active'));
            this.classList.add('nav__item--active');
        });
    });
}

function switchView(viewName) {
    const views = document.querySelectorAll('.view');
    views.forEach(view => view.classList.remove('view--active'));
    
    const targetView = document.getElementById(viewName);
    if (targetView) {
        targetView.classList.add('view--active');
        currentView = viewName;
        
        // Initialize view-specific functionality
        if (viewName === 'analytics') {
            setTimeout(() => {
                setupAnalyticsCharts();
            }, 100);
        }
    }
}

// Time Display
function setupTime() {
    function updateTime() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        const dateString = now.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
        
        const timeElement = document.getElementById('currentTime');
        if (timeElement) {
            timeElement.textContent = `${dateString} ${timeString}`;
        }
    }
    
    updateTime();
    setInterval(updateTime, 1000);
}

// Dashboard Population
function populateDashboard() {
    // Update statistics
    document.getElementById('totalProjects').textContent = appData.platform_stats.total_projects;
    document.getElementById('activeUsers').textContent = appData.platform_stats.active_users;
    document.getElementById('costSavings').textContent = appData.platform_stats.total_cost_savings;
    document.getElementById('timeReduction').textContent = appData.platform_stats.time_reduction;

    // Populate activity feed
    const activityList = document.getElementById('activityList');
    if (activityList) {
        activityList.innerHTML = appData.recent_activities.map(activity => `
            <div class="activity-item">
                <span class="activity-user">${activity.user}</span> ${activity.action} in <strong>${activity.project}</strong>
                <div class="activity-time">${activity.time}</div>
            </div>
        `).join('');
    }

    // Populate collaboration sessions
    const sessionList = document.getElementById('sessionList');
    if (sessionList) {
        sessionList.innerHTML = appData.collaboration_sessions.map(session => `
            <div class="session-item">
                <div class="session-status">
                    <div class="session-indicator"></div>
                    <strong>${session.project}</strong> - ${session.status}
                </div>
                <div style="font-size: var(--font-size-sm); color: var(--color-text-secondary); margin-top: var(--space-4);">
                    ${session.participants.join(', ')}
                    ${session.status === 'Live' ? `(${session.duration})` : session.start_time ? `starts at ${session.start_time}` : ''}
                </div>
            </div>
        `).join('');
    }
}

// Project Management
function setupProjectManagement() {
    const statusFilter = document.getElementById('statusFilter');
    const projectSearch = document.getElementById('projectSearch');

    if (statusFilter) {
        statusFilter.addEventListener('change', filterProjects);
    }

    if (projectSearch) {
        projectSearch.addEventListener('input', filterProjects);
    }
}

function populateProjects() {
    const projectGrid = document.getElementById('projectGrid');
    if (!projectGrid) return;

    projectGrid.innerHTML = filteredProjects.map(project => `
        <div class="project-card">
            <div class="project-card__header">
                <h3 class="project-card__title">${project.name}</h3>
                <span class="project-card__id">${project.id}</span>
            </div>
            <div class="project-card__stats">
                <div class="project-stat">
                    <div class="project-stat__value">${project.team_members}</div>
                    <div class="project-stat__label">Team Members</div>
                </div>
                <div class="project-stat">
                    <div class="project-stat__value">${project.cost_savings}</div>
                    <div class="project-stat__label">Cost Savings</div>
                </div>
                <div class="project-stat">
                    <div class="project-stat__value">${project.time_saved}</div>
                    <div class="project-stat__label">Time Saved</div>
                </div>
                <div class="project-stat">
                    <div class="project-stat__value">${getStatusBadge(project.status)}</div>
                    <div class="project-stat__label">Status</div>
                </div>
            </div>
            <div class="project-card__progress">
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${project.completion}%"></div>
                </div>
                <div style="text-align: center; margin-top: var(--space-8); font-size: var(--font-size-sm);">
                    ${project.completion}% Complete
                </div>
            </div>
            <div class="project-card__actions">
                <button class="btn btn--sm btn--outline" onclick="openProject('${project.id}')">Open</button>
                <button class="btn btn--sm btn--secondary" onclick="shareProject('${project.id}')">Share</button>
            </div>
        </div>
    `).join('');
}

function getStatusBadge(status) {
    const statusColors = {
        'Active': 'var(--color-success)',
        'Review': 'var(--color-warning)',
        'Testing': 'var(--color-info)'
    };
    const color = statusColors[status] || 'var(--color-text-secondary)';
    return `<span style="color: ${color}; font-weight: var(--font-weight-semibold);">${status}</span>`;
}

function filterProjects() {
    const statusFilter = document.getElementById('statusFilter');
    const projectSearch = document.getElementById('projectSearch');
    
    const statusValue = statusFilter ? statusFilter.value : '';
    const searchValue = projectSearch ? projectSearch.value.toLowerCase() : '';
    
    filteredProjects = appData.projects.filter(project => {
        const matchesStatus = !statusValue || project.status === statusValue;
        const matchesSearch = !searchValue || 
            project.name.toLowerCase().includes(searchValue) || 
            project.id.toLowerCase().includes(searchValue);
        
        return matchesStatus && matchesSearch;
    });
    
    populateProjects();
}

function openProject(projectId) {
    alert(`Opening project ${projectId} in virtual studio...`);
    switchView('prototyping-studio');
    document.querySelector('[data-view="prototyping-studio"]').classList.add('nav__item--active');
    document.querySelectorAll('.nav__item').forEach(item => {
        if (item.dataset.view !== 'prototyping-studio') {
            item.classList.remove('nav__item--active');
        }
    });
}

function shareProject(projectId) {
    alert(`Sharing project ${projectId} with team members...`);
}

// Collaboration Hub
function setupCollaborationHub() {
    const startSessionBtn = document.getElementById('startSessionBtn');
    const sendChatBtn = document.getElementById('sendChatBtn');
    const chatInput = document.getElementById('chatInput');

    if (startSessionBtn) {
        startSessionBtn.addEventListener('click', startCollaborationSession);
    }

    if (sendChatBtn) {
        sendChatBtn.addEventListener('click', sendChatMessage);
    }

    if (chatInput) {
        chatInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendChatMessage();
            }
        });
    }

    populateCollaborationSessions();
}

function populateCollaborationSessions() {
    const sessionsContainer = document.getElementById('collaborationSessions');
    if (!sessionsContainer) return;

    sessionsContainer.innerHTML = appData.collaboration_sessions.map(session => `
        <div class="session-item">
            <div class="session-status">
                <div class="session-indicator"></div>
                <strong>${session.project}</strong>
            </div>
            <div style="font-size: var(--font-size-sm); color: var(--color-text-secondary); margin: var(--space-8) 0;">
                ${session.participants.length} participants: ${session.participants.join(', ')}
            </div>
            <div style="font-size: var(--font-size-sm); color: var(--color-text-secondary);">
                Status: ${session.status}
                ${session.duration ? ` | Duration: ${session.duration}` : ''}
                ${session.start_time ? ` | Starts: ${session.start_time}` : ''}
            </div>
            <button class="btn btn--sm btn--primary" style="margin-top: var(--space-8);" onclick="joinSession('${session.project}')">
                ${session.status === 'Live' ? 'Join' : 'Schedule'}
            </button>
        </div>
    `).join('');
}

function startCollaborationSession() {
    alert('Starting new collaboration session...');
}

function joinSession(project) {
    alert(`Joining collaboration session for ${project}...`);
}

function sendChatMessage() {
    const chatInput = document.getElementById('chatInput');
    const chatMessages = document.getElementById('chatMessages');
    
    if (chatInput && chatMessages && chatInput.value.trim()) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'chat-message';
        messageDiv.innerHTML = `<strong>You:</strong> ${chatInput.value}`;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        chatInput.value = '';
    }
}

// Resource Library
function setupResourceLibrary() {
    const tabBtns = document.querySelectorAll('.tab-btn');
    const uploadBtn = document.getElementById('uploadResourceBtn');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const tabId = this.dataset.tab;
            switchTab(tabId);
            
            // Update active state
            tabBtns.forEach(tab => tab.classList.remove('tab-btn--active'));
            this.classList.add('tab-btn--active');
        });
    });

    if (uploadBtn) {
        uploadBtn.addEventListener('click', function() {
            alert('Upload functionality would be implemented here...');
        });
    }
}

function switchTab(tabId) {
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(content => content.classList.remove('tab-content--active'));
    
    const targetTab = document.getElementById(tabId);
    if (targetTab) {
        targetTab.classList.add('tab-content--active');
    }
}

// Modal System
function setupModal() {
    const newProjectBtn = document.getElementById('newProjectBtn');
    const modal = document.getElementById('newProjectModal');
    const closeModal = document.getElementById('closeModal');
    const modalOverlay = document.getElementById('modalOverlay');
    const cancelProject = document.getElementById('cancelProject');
    const createProject = document.getElementById('createProject');

    if (newProjectBtn) {
        newProjectBtn.addEventListener('click', function() {
            modal.classList.remove('hidden');
        });
    }

    function hideModal() {
        modal.classList.add('hidden');
        // Clear form
        document.getElementById('projectName').value = '';
        document.getElementById('teamMembers').value = '';
    }

    if (closeModal) closeModal.addEventListener('click', hideModal);
    if (modalOverlay) modalOverlay.addEventListener('click', hideModal);
    if (cancelProject) cancelProject.addEventListener('click', hideModal);

    if (createProject) {
        createProject.addEventListener('click', function() {
            const projectName = document.getElementById('projectName').value;
            const projectType = document.getElementById('projectType').value;
            const teamMembers = document.getElementById('teamMembers').value;

            if (projectName.trim()) {
                // Create new project
                const newProject = {
                    id: `PRJ${String(appData.projects.length + 1).padStart(3, '0')}`,
                    name: projectName,
                    status: 'Active',
                    team_members: teamMembers.split(',').length,
                    cost_savings: '$0',
                    time_saved: '0 weeks',
                    completion: 0
                };

                appData.projects.push(newProject);
                filteredProjects = [...appData.projects];
                populateProjects();
                hideModal();
                alert(`Project "${projectName}" created successfully!`);
            } else {
                alert('Please enter a project name.');
            }
        });
    }
}

// Charts
function setupCharts() {
    // Only initialize charts if we're on the dashboard or if elements exist
    if (document.getElementById('costSavingsChart') || document.getElementById('productivityChart')) {
        setupAnalyticsCharts();
    }
}

function setupAnalyticsCharts() {
    createCostSavingsChart();
    createProductivityChart();
}

function createCostSavingsChart() {
    const ctx = document.getElementById('costSavingsChart');
    if (!ctx) return;

    // Generate mock data for monthly cost savings
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
    const savings = [320000, 450000, 380000, 520000, 480000, 600000];

    costSavingsChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: months,
            datasets: [{
                label: 'Monthly Savings ($)',
                data: savings,
                borderColor: '#1FB8CD',
                backgroundColor: 'rgba(31, 184, 205, 0.1)',
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#1FB8CD',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '$' + (value / 1000) + 'K';
                        }
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index'
            }
        }
    });
}

function createProductivityChart() {
    const ctx = document.getElementById('productivityChart');
    if (!ctx) return;

    // Generate mock productivity data
    const weeks = ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6'];
    const traditional = [100, 105, 98, 110, 95, 108];
    const immersive = [180, 195, 185, 210, 190, 220];

    productivityChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: weeks,
            datasets: [{
                label: 'Traditional Method',
                data: traditional,
                backgroundColor: '#B4413C',
                borderRadius: 4
            }, {
                label: 'Immersive Platform',
                data: immersive,
                backgroundColor: '#1FB8CD',
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Productivity Index'
                    }
                }
            }
        }
    });
}

// Virtual Prototyping Studio Functions
function setupVirtualStudio() {
    const importModelBtn = document.getElementById('importModelBtn');
    const startVRBtn = document.getElementById('startVRBtn');

    if (importModelBtn) {
        importModelBtn.addEventListener('click', function() {
            alert('3D model import functionality would be implemented here...');
        });
    }

    if (startVRBtn) {
        startVRBtn.addEventListener('click', function() {
            alert('Initializing VR session...');
        });
    }
}

// Analytics Functions
function setupAnalytics() {
    const generateReportBtn = document.getElementById('generateReportBtn');
    const exportDataBtn = document.getElementById('exportDataBtn');

    if (generateReportBtn) {
        generateReportBtn.addEventListener('click', generateReport);
    }

    if (exportDataBtn) {
        exportDataBtn.addEventListener('click', exportAnalyticsData);
    }
}

function generateReport() {
    const reportData = {
        timestamp: new Date().toISOString(),
        platform_stats: appData.platform_stats,
        performance_metrics: appData.performance_metrics,
        projects: appData.projects,
        collaboration_sessions: appData.collaboration_sessions
    };

    const reportContent = `
# Industrial Prototyping Platform Report
Generated: ${new Date().toLocaleDateString()}

## Platform Statistics
- Total Projects: ${appData.platform_stats.total_projects}
- Active Users: ${appData.platform_stats.active_users}
- Total Cost Savings: ${appData.platform_stats.total_cost_savings}
- Time Reduction: ${appData.platform_stats.time_reduction}
- Safety Incidents Reduced: ${appData.platform_stats.safety_incidents_reduced}

## Performance Metrics
${appData.performance_metrics.map(metric => `
- ${metric.metric}: ${metric.savings || metric.reduction}`).join('')}

## Active Projects
${appData.projects.map(project => `
- ${project.name} (${project.id}): ${project.completion}% complete, ${project.cost_savings} saved`).join('')}
    `;

    // Create and download report
    const blob = new Blob([reportContent], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `industrial_prototyping_report_${new Date().toISOString().split('T')[0]}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    alert('Report generated and downloaded successfully!');
}

function exportAnalyticsData() {
    const analyticsData = {
        export_date: new Date().toISOString(),
        platform_statistics: appData.platform_stats,
        performance_metrics: appData.performance_metrics,
        project_data: appData.projects,
        collaboration_data: appData.collaboration_sessions,
        recent_activities: appData.recent_activities
    };

    const blob = new Blob([JSON.stringify(analyticsData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analytics_export_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    alert('Analytics data exported successfully!');
}

// Additional setup when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    setupVirtualStudio();
    setupAnalytics();

    // Add some interactivity to buttons that weren't covered
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        if (!button.onclick && !button.id && !button.dataset.view && !button.classList.contains('nav__item')) {
            button.addEventListener('click', function() {
                const buttonText = this.textContent.trim();
                if (buttonText && !['Send', 'Create Project', 'Cancel'].includes(buttonText)) {
                    console.log(`${buttonText} functionality would be implemented here...`);
                }
            });
        }
    });

    // Simulate real-time updates for dashboard
    setInterval(() => {
        if (currentView === 'dashboard') {
            simulateRealTimeUpdates();
        }
    }, 30000); // Update every 30 seconds
});

function simulateRealTimeUpdates() {
    // Simulate small changes in statistics
    const totalProjectsElement = document.getElementById('totalProjects');
    const activeUsersElement = document.getElementById('activeUsers');
    
    if (totalProjectsElement && Math.random() > 0.8) {
        const currentValue = parseInt(totalProjectsElement.textContent);
        totalProjectsElement.textContent = currentValue + Math.floor(Math.random() * 3);
    }
    
    if (activeUsersElement && Math.random() > 0.7) {
        const currentValue = parseInt(activeUsersElement.textContent);
        const change = Math.floor(Math.random() * 10) - 5; // -5 to +5 users
        activeUsersElement.textContent = Math.max(0, currentValue + change);
    }
}

// Error handling
window.addEventListener('error', function(e) {
    console.error('Application error:', e.error);
});

// Make functions available globally for onclick handlers
window.openProject = openProject;
window.shareProject = shareProject;
window.joinSession = joinSession;