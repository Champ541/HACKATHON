
# potato_defect_model.py - CNN Model Training for Potato Defect Detection

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, models
import numpy as np
import cv2
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
from datetime import datetime
import json

# Set random seeds for reproducibility
tf.random.set_seed(42)
np.random.seed(42)

class PotatoDefectCNN:
    def __init__(self, input_shape=(224, 224, 3), num_classes=4):
        self.input_shape = input_shape
        self.num_classes = num_classes
        self.model = None
        self.history = None
        self.class_names = ['Healthy', 'Hollow Heart', 'Black Heart', 'Internal Heat Necrosis']

    def create_model(self):
        """Create CNN model architecture optimized for potato defect detection"""
        model = models.Sequential([
            # Data augmentation layers
            layers.RandomFlip('horizontal'),
            layers.RandomRotation(0.1),
            layers.RandomZoom(0.1),

            # Convolutional base
            layers.Conv2D(32, (3, 3), activation='relu', input_shape=self.input_shape),
            layers.BatchNormalization(),
            layers.MaxPooling2D((2, 2)),
            layers.Dropout(0.25),

            layers.Conv2D(64, (3, 3), activation='relu'),
            layers.BatchNormalization(),
            layers.MaxPooling2D((2, 2)),
            layers.Dropout(0.25),

            layers.Conv2D(128, (3, 3), activation='relu'),
            layers.BatchNormalization(),
            layers.MaxPooling2D((2, 2)),
            layers.Dropout(0.25),

            layers.Conv2D(256, (3, 3), activation='relu'),
            layers.BatchNormalization(),
            layers.MaxPooling2D((2, 2)),
            layers.Dropout(0.25),

            # Classifier
            layers.Flatten(),
            layers.Dense(512, activation='relu'),
            layers.BatchNormalization(),
            layers.Dropout(0.5),
            layers.Dense(256, activation='relu'),
            layers.BatchNormalization(),
            layers.Dropout(0.5),
            layers.Dense(self.num_classes, activation='softmax')
        ])

        # Compile model
        model.compile(
            optimizer=keras.optimizers.Adam(learning_rate=0.001),
            loss='categorical_crossentropy',
            metrics=['accuracy', 'precision', 'recall']
        )

        self.model = model
        return model

    def load_and_preprocess_data(self, data_dir):
        """Load and preprocess potato images from directory structure"""
        images = []
        labels = []

        for class_idx, class_name in enumerate(self.class_names):
            class_path = os.path.join(data_dir, class_name)
            if not os.path.exists(class_path):
                print(f"Warning: Directory {class_path} not found")
                continue

            for image_name in os.listdir(class_path):
                if image_name.lower().endswith(('.png', '.jpg', '.jpeg')):
                    image_path = os.path.join(class_path, image_name)

                    try:
                        # Load and preprocess image
                        image = cv2.imread(image_path)
                        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                        image = cv2.resize(image, self.input_shape[:2])
                        image = image.astype(np.float32) / 255.0

                        images.append(image)

                        # Create one-hot encoded label
                        label = np.zeros(self.num_classes)
                        label[class_idx] = 1
                        labels.append(label)

                    except Exception as e:
                        print(f"Error loading image {image_path}: {e}")
                        continue

        return np.array(images), np.array(labels)

    def train_model(self, data_dir, epochs=50, batch_size=32, validation_split=0.2):
        """Train the CNN model"""
        print("Loading and preprocessing data...")
        X, y = self.load_and_preprocess_data(data_dir)

        print(f"Dataset shape: {X.shape}")
        print(f"Labels shape: {y.shape}")

        # Split data
        X_train, X_val, y_train, y_val = train_test_split(
            X, y, test_size=validation_split, random_state=42, stratify=y.argmax(axis=1)
        )

        # Create model
        if self.model is None:
            self.create_model()

        # Callbacks
        callbacks = [
            keras.callbacks.EarlyStopping(
                patience=10, restore_best_weights=True, monitor='val_accuracy'
            ),
            keras.callbacks.ReduceLROnPlateau(
                factor=0.5, patience=5, min_lr=1e-7, monitor='val_loss'
            ),
            keras.callbacks.ModelCheckpoint(
                'best_model.h5', save_best_only=True, monitor='val_accuracy'
            )
        ]

        # Train model
        print("Starting model training...")
        self.history = self.model.fit(
            X_train, y_train,
            batch_size=batch_size,
            epochs=epochs,
            validation_data=(X_val, y_val),
            callbacks=callbacks,
            verbose=1
        )

        # Evaluate model
        print("Evaluating model...")
        val_loss, val_accuracy, val_precision, val_recall = self.model.evaluate(
            X_val, y_val, verbose=0
        )

        print(f"Validation Accuracy: {val_accuracy:.4f}")
        print(f"Validation Precision: {val_precision:.4f}")
        print(f"Validation Recall: {val_recall:.4f}")

        # Generate predictions for classification report
        y_pred = self.model.predict(X_val)
        y_pred_classes = np.argmax(y_pred, axis=1)
        y_true_classes = np.argmax(y_val, axis=1)

        # Print classification report
        print("\nClassification Report:")
        print(classification_report(
            y_true_classes, y_pred_classes, target_names=self.class_names
        ))

        return self.history

    def plot_training_history(self):
        """Plot training history"""
        if self.history is None:
            print("No training history available")
            return

        fig, axes = plt.subplots(2, 2, figsize=(12, 10))

        # Accuracy
        axes[0, 0].plot(self.history.history['accuracy'], label='Training')
        axes[0, 0].plot(self.history.history['val_accuracy'], label='Validation')
        axes[0, 0].set_title('Model Accuracy')
        axes[0, 0].set_xlabel('Epoch')
        axes[0, 0].set_ylabel('Accuracy')
        axes[0, 0].legend()

        # Loss
        axes[0, 1].plot(self.history.history['loss'], label='Training')
        axes[0, 1].plot(self.history.history['val_loss'], label='Validation')
        axes[0, 1].set_title('Model Loss')
        axes[0, 1].set_xlabel('Epoch')
        axes[0, 1].set_ylabel('Loss')
        axes[0, 1].legend()

        # Precision
        axes[1, 0].plot(self.history.history['precision'], label='Training')
        axes[1, 0].plot(self.history.history['val_precision'], label='Validation')
        axes[1, 0].set_title('Model Precision')
        axes[1, 0].set_xlabel('Epoch')
        axes[1, 0].set_ylabel('Precision')
        axes[1, 0].legend()

        # Recall
        axes[1, 1].plot(self.history.history['recall'], label='Training')
        axes[1, 1].plot(self.history.history['val_recall'], label='Validation')
        axes[1, 1].set_title('Model Recall')
        axes[1, 1].set_xlabel('Epoch')
        axes[1, 1].set_ylabel('Recall')
        axes[1, 1].legend()

        plt.tight_layout()
        plt.savefig('training_history.png', dpi=300, bbox_inches='tight')
        plt.show()

    def save_model(self, filepath):
        """Save the trained model"""
        if self.model is None:
            print("No model to save")
            return

        self.model.save(filepath)

        # Save model metadata
        metadata = {
            'model_version': 'v2.3',
            'training_date': datetime.now().isoformat(),
            'input_shape': self.input_shape,
            'num_classes': self.num_classes,
            'class_names': self.class_names
        }

        with open(filepath.replace('.h5', '_metadata.json'), 'w') as f:
            json.dump(metadata, f, indent=2)

        print(f"Model saved to {filepath}")

# Usage example
if __name__ == "__main__":
    # Initialize model
    potato_cnn = PotatoDefectCNN()

    # Train model (uncomment when you have data)
    # history = potato_cnn.train_model('path/to/potato/dataset')
    # potato_cnn.plot_training_history()
    # potato_cnn.save_model('potato_defect_model_v2.3.h5')

    print("Model training code is ready!")
