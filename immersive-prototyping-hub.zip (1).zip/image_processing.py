
# image_processing.py - Image Processing Utilities for Potato Defect Detection

import cv2
import numpy as np
from scipy import ndimage
from skimage import filters, measure, morphology
from typing import Tuple, List, Dict
import matplotlib.pyplot as plt

class PotatoImageProcessor:
    """Image processing utilities for potato quality assessment"""

    def __init__(self):
        self.supported_formats = ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']

    def load_image(self, image_path: str) -> np.ndarray:
        """Load image from file path"""
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not load image from {image_path}")
        return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    def preprocess_for_ai(self, image: np.ndarray, target_size: Tuple[int, int] = (224, 224)) -> np.ndarray:
        """Preprocess image for AI model input"""
        # Resize image
        processed = cv2.resize(image, target_size)

        # Normalize pixel values
        processed = processed.astype(np.float32) / 255.0

        # Apply histogram equalization for better contrast
        processed = self.enhance_contrast(processed)

        return processed

    def enhance_contrast(self, image: np.ndarray) -> np.ndarray:
        """Enhance image contrast using CLAHE"""
        # Convert to LAB color space
        lab = cv2.cvtColor(image, cv2.COLOR_RGB2LAB)

        # Apply CLAHE to L channel
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        lab[:, :, 0] = clahe.apply((lab[:, :, 0] * 255).astype(np.uint8)) / 255.0

        # Convert back to RGB
        enhanced = cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)
        return enhanced

    def detect_potato_region(self, image: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Detect and segment potato region from background"""
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)

        # Apply Gaussian blur
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)

        # Threshold to create binary mask
        _, threshold = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        # Morphological operations to clean up mask
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        mask = cv2.morphologyEx(threshold, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        # Find largest contour (potato)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            largest_contour = max(contours, key=cv2.contourArea)

            # Create refined mask
            refined_mask = np.zeros_like(mask)
            cv2.drawContours(refined_mask, [largest_contour], -1, 255, -1)

            # Apply mask to original image
            segmented = image.copy()
            segmented[refined_mask == 0] = [0, 0, 0]

            return segmented, refined_mask

        return image, mask

    def extract_surface_features(self, image: np.ndarray) -> Dict:
        """Extract surface features for defect analysis"""
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)

        features = {}

        # Texture analysis using Local Binary Pattern
        features['texture_variance'] = cv2.Laplacian(gray, cv2.CV_64F).var()

        # Edge detection for surface irregularities
        edges = cv2.Canny(gray, 50, 150)
        features['edge_density'] = np.sum(edges > 0) / edges.size

        # Color analysis
        features['mean_brightness'] = np.mean(gray)
        features['brightness_std'] = np.std(gray)

        # Surface roughness estimation
        sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        gradient_magnitude = np.sqrt(sobel_x**2 + sobel_y**2)
        features['surface_roughness'] = np.mean(gradient_magnitude)

        return features

    def analyze_shape(self, mask: np.ndarray) -> Dict:
        """Analyze potato shape characteristics"""
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        if not contours:
            return {}

        largest_contour = max(contours, key=cv2.contourArea)

        # Calculate shape features
        area = cv2.contourArea(largest_contour)
        perimeter = cv2.arcLength(largest_contour, True)

        # Roundness (4π * area / perimeter²)
        roundness = (4 * np.pi * area) / (perimeter ** 2) if perimeter > 0 else 0

        # Aspect ratio
        x, y, w, h = cv2.boundingRect(largest_contour)
        aspect_ratio = w / h if h > 0 else 0

        # Solidity (area / convex hull area)
        hull = cv2.convexHull(largest_contour)
        hull_area = cv2.contourArea(hull)
        solidity = area / hull_area if hull_area > 0 else 0

        return {
            'area': area,
            'perimeter': perimeter,
            'roundness': roundness,
            'aspect_ratio': aspect_ratio,
            'solidity': solidity,
            'bounding_box': (x, y, w, h)
        }

    def detect_surface_defects(self, image: np.ndarray) -> List[Dict]:
        """Detect visible surface defects"""
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)

        defects = []

        # Detect dark spots (potential bruises or rot)
        dark_threshold = np.percentile(gray, 20)  # Bottom 20% of pixel values
        dark_spots = gray < dark_threshold

        # Label connected components
        labeled_spots = measure.label(dark_spots)
        regions = measure.regionprops(labeled_spots)

        for region in regions:
            if region.area > 50:  # Filter small noise
                defects.append({
                    'type': 'dark_spot',
                    'area': region.area,
                    'centroid': region.centroid,
                    'bbox': region.bbox,
                    'intensity': np.mean(gray[labeled_spots == region.label])
                })

        # Detect bright spots (potential sprouting or growth)
        bright_threshold = np.percentile(gray, 90)  # Top 10% of pixel values
        bright_spots = gray > bright_threshold

        labeled_bright = measure.label(bright_spots)
        bright_regions = measure.regionprops(labeled_bright)

        for region in bright_regions:
            if region.area > 30:
                defects.append({
                    'type': 'bright_spot',
                    'area': region.area,
                    'centroid': region.centroid,
                    'bbox': region.bbox,
                    'intensity': np.mean(gray[labeled_bright == region.label])
                })

        return defects

    def visualize_analysis(self, original_image: np.ndarray, mask: np.ndarray, 
                          defects: List[Dict], save_path: str = None):
        """Visualize image analysis results"""
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))

        # Original image
        axes[0, 0].imshow(original_image)
        axes[0, 0].set_title('Original Image')
        axes[0, 0].axis('off')

        # Segmented potato
        segmented, _ = self.detect_potato_region(original_image)
        axes[0, 1].imshow(segmented)
        axes[0, 1].set_title('Segmented Potato')
        axes[0, 1].axis('off')

        # Mask
        axes[1, 0].imshow(mask, cmap='gray')
        axes[1, 0].set_title('Potato Mask')
        axes[1, 0].axis('off')

        # Defects overlay
        defect_overlay = original_image.copy()
        for defect in defects:
            bbox = defect['bbox']
            y1, x1, y2, x2 = bbox
            cv2.rectangle(defect_overlay, (x1, y1), (x2, y2), (255, 0, 0), 2)

        axes[1, 1].imshow(defect_overlay)
        axes[1, 1].set_title(f'Detected Defects ({len(defects)})')
        axes[1, 1].axis('off')

        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')

        plt.show()

# Usage example
if __name__ == "__main__":
    processor = PotatoImageProcessor()

    # Example processing pipeline
    # image = processor.load_image('path/to/potato/image.jpg')
    # segmented, mask = processor.detect_potato_region(image)
    # surface_features = processor.extract_surface_features(segmented)
    # shape_features = processor.analyze_shape(mask)
    # defects = processor.detect_surface_defects(segmented)
    # processor.visualize_analysis(image, mask, defects)

    print("Image processing utilities are ready!")
