
# hardware_integration.py - Hardware Integration for Potato Defect Detection System

import serial
import time
import threading
import logging
from typing import Dict, List, Optional
import json
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ConveyorController:
    """Control conveyor belt system"""

    def __init__(self, serial_port: str = '/dev/ttyUSB0', baud_rate: int = 9600):
        self.serial_port = serial_port
        self.baud_rate = baud_rate
        self.connection = None
        self.is_running = False
        self.speed = 50  # Default speed (0-100)

    def connect(self):
        """Establish connection to conveyor controller"""
        try:
            self.connection = serial.Serial(self.serial_port, self.baud_rate, timeout=1)
            logger.info(f"Connected to conveyor on {self.serial_port}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to conveyor: {e}")
            return False

    def start(self):
        """Start conveyor belt"""
        if self.connection:
            command = f"START,{self.speed}\n"
            self.connection.write(command.encode())
            self.is_running = True
            logger.info(f"Conveyor started at speed {self.speed}")

    def stop(self):
        """Stop conveyor belt"""
        if self.connection:
            self.connection.write(b"STOP\n")
            self.is_running = False
            logger.info("Conveyor stopped")

    def set_speed(self, speed: int):
        """Set conveyor speed (0-100)"""
        self.speed = max(0, min(100, speed))
        if self.connection and self.is_running:
            command = f"SPEED,{self.speed}\n"
            self.connection.write(command.encode())
            logger.info(f"Conveyor speed set to {self.speed}")

class SortingMechanism:
    """Control pneumatic sorting system"""

    def __init__(self, serial_port: str = '/dev/ttyUSB1', baud_rate: int = 9600):
        self.serial_port = serial_port
        self.baud_rate = baud_rate
        self.connection = None
        self.sort_bins = {
            'healthy': 1,
            'hollow_heart': 2,
            'black_heart': 3,
            'internal_heat_necrosis': 4,
            'reject': 5
        }

    def connect(self):
        """Establish connection to sorting controller"""
        try:
            self.connection = serial.Serial(self.serial_port, self.baud_rate, timeout=1)
            logger.info(f"Connected to sorting system on {self.serial_port}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to sorting system: {e}")
            return False

    def sort_potato(self, defect_type: str, delay_ms: int = 0):
        """Sort potato into appropriate bin"""
        if not self.connection:
            logger.error("Sorting system not connected")
            return

        bin_number = self.sort_bins.get(defect_type.lower().replace(' ', '_'), 5)

        if delay_ms > 0:
            time.sleep(delay_ms / 1000.0)  # Convert ms to seconds

        command = f"SORT,{bin_number}\n"
        self.connection.write(command.encode())
        logger.info(f"Sorted {defect_type} to bin {bin_number}")

class SensorArray:
    """Manage multiple sensors (cameras, spectroscopy, etc.)"""

    def __init__(self):
        self.sensors = {}
        self.is_monitoring = False
        self.data_callback = None

    def add_sensor(self, sensor_id: str, sensor_type: str, config: Dict):
        """Add a sensor to the array"""
        self.sensors[sensor_id] = {
            'type': sensor_type,
            'config': config,
            'status': 'inactive'
        }
        logger.info(f"Added {sensor_type} sensor: {sensor_id}")

    def activate_sensor(self, sensor_id: str):
        """Activate a specific sensor"""
        if sensor_id in self.sensors:
            self.sensors[sensor_id]['status'] = 'active'
            logger.info(f"Activated sensor: {sensor_id}")

    def deactivate_sensor(self, sensor_id: str):
        """Deactivate a specific sensor"""
        if sensor_id in self.sensors:
            self.sensors[sensor_id]['status'] = 'inactive'
            logger.info(f"Deactivated sensor: {sensor_id}")

    def start_monitoring(self, callback_function):
        """Start continuous sensor monitoring"""
        self.data_callback = callback_function
        self.is_monitoring = True

        # Start monitoring thread
        monitoring_thread = threading.Thread(target=self._monitor_sensors)
        monitoring_thread.daemon = True
        monitoring_thread.start()

        logger.info("Started sensor monitoring")

    def _monitor_sensors(self):
        """Internal sensor monitoring loop"""
        while self.is_monitoring:
            for sensor_id, sensor in self.sensors.items():
                if sensor['status'] == 'active':
                    # Simulate sensor data collection
                    sensor_data = {
                        'sensor_id': sensor_id,
                        'timestamp': datetime.now().isoformat(),
                        'type': sensor['type'],
                        'data': self._collect_sensor_data(sensor_id)
                    }

                    if self.data_callback:
                        self.data_callback(sensor_data)

            time.sleep(0.1)  # 100ms monitoring interval

    def _collect_sensor_data(self, sensor_id: str) -> Dict:
        """Simulate sensor data collection"""
        sensor_type = self.sensors[sensor_id]['type']

        if sensor_type == 'camera':
            return {'image_captured': True, 'image_path': f'images/{sensor_id}_{int(time.time())}.jpg'}
        elif sensor_type == 'spectroscopy':
            return {'spectrum': [i * 0.1 for i in range(100)], 'wavelengths': list(range(400, 1000, 6))}
        else:
            return {'status': 'data_collected'}

class SystemController:
    """Main system controller integrating all hardware components"""

    def __init__(self):
        self.conveyor = ConveyorController()
        self.sorter = SortingMechanism()
        self.sensors = SensorArray()
        self.is_running = False
        self.processing_queue = []
        self.stats = {
            'potatoes_processed': 0,
            'defects_detected': 0,
            'system_uptime': 0
        }

    def initialize_system(self):
        """Initialize all hardware components"""
        logger.info("Initializing potato defect detection system...")

        # Connect hardware
        conveyor_ok = self.conveyor.connect()
        sorter_ok = self.sorter.connect()

        # Setup sensors
        self.sensors.add_sensor('camera_1', 'camera', {'resolution': '1920x1080'})
        self.sensors.add_sensor('spectrometer_1', 'spectroscopy', {'range': '400-1000nm'})

        if conveyor_ok and sorter_ok:
            logger.info("System initialization complete")
            return True
        else:
            logger.error("System initialization failed")
            return False

    def start_production(self):
        """Start production line"""
        if not self.is_running:
            self.is_running = True

            # Start conveyor
            self.conveyor.start()

            # Activate sensors
            self.sensors.activate_sensor('camera_1')
            self.sensors.activate_sensor('spectrometer_1')

            # Start sensor monitoring
            self.sensors.start_monitoring(self._process_sensor_data)

            logger.info("Production started")

    def stop_production(self):
        """Stop production line"""
        if self.is_running:
            self.is_running = False

            # Stop conveyor
            self.conveyor.stop()

            # Deactivate sensors
            for sensor_id in self.sensors.sensors.keys():
                self.sensors.deactivate_sensor(sensor_id)

            self.sensors.is_monitoring = False

            logger.info("Production stopped")

    def _process_sensor_data(self, sensor_data: Dict):
        """Process incoming sensor data"""
        # Add to processing queue
        self.processing_queue.append(sensor_data)

        # In real implementation, this would trigger AI analysis
        # and sorting decisions
        logger.debug(f"Received data from {sensor_data['sensor_id']}")

    def sort_potato(self, defect_type: str, confidence: float):
        """Sort potato based on AI detection results"""
        if confidence > 0.8:  # High confidence threshold
            self.sorter.sort_potato(defect_type)

            if defect_type != 'Healthy':
                self.stats['defects_detected'] += 1

            self.stats['potatoes_processed'] += 1
        else:
            # Low confidence - sort to manual inspection bin
            self.sorter.sort_potato('reject')

    def get_system_status(self) -> Dict:
        """Get current system status"""
        return {
            'is_running': self.is_running,
            'conveyor_speed': self.conveyor.speed,
            'active_sensors': [
                sid for sid, sensor in self.sensors.sensors.items() 
                if sensor['status'] == 'active'
            ],
            'processing_queue_size': len(self.processing_queue),
            'statistics': self.stats
        }

# Usage example
if __name__ == "__main__":
    system = SystemController()

    if system.initialize_system():
        print("System ready for production")
        # system.start_production()
        # time.sleep(10)  # Run for 10 seconds
        # system.stop_production()
    else:
        print("System initialization failed")
